import NotesApi from '../data/remote/notes-api.js'

class SearchNote extends HTMLElement {
    constructor()  {
      super();
      // this._shadowRoot = this.attachShadow({ mode: 'open' });
    }
    
    connectedCallback() {
       
        this.render();
      }

    listenButtonToSearch(searchInputvalue){
        var data = [];
        this.querySelector(".searchButton").addEventListener("click", () => {
           data = NotesApi.searchNote(searchInputvalue,"dada");
        });
        console.log(data);
        return data;
    }
    render(){
       return this.innerHTML = `
        <div id="search-container">
            <input type="text" class="searchInput" placeholder="Search notes...">
            <button class="searchButton"><i class="fas fa-search"></i> Search</button>
            <button class="resetButton"><i class="fas fa-sync-alt"></i> Reset</button>
        </div>
        `;
      }
    }
  
    
    customElements.define('search-note', SearchNote);
  
    export default SearchNote;