class LoadingIndicator extends HTMLElement {
  constructor()  {
    super();
    // this._shadowRoot = this.attachShadow({ mode: 'open' });
  }
  
  connectedCallback() {
      this.render();
    }

    render(){
        return this.innerHTML = `
        <div class="loading-indicator">
          <!-- Tambahkan elemen atau animasi loading di sini -->
          <div class="spinner"></div>
          <p>Loading...</p>
        </div>
      `;
    }
  }

  
  customElements.define('loading-indicators', LoadingIndicator);

  export default LoadingIndicator;