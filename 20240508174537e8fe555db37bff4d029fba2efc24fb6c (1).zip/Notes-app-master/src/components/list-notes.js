const apiUrl = 'https://notes-api.dicoding.dev/v2/notes';
var notesData =[];
// Kelas NoteCard untuk menampilkan detail catatan
class NoteCard extends HTMLElement {
  constructor() {
    super();
  }
    connectedCallback() {
      const id = this.getAttribute('id');
      const title = this.getAttribute('title');
      const body = this.getAttribute('body');
      const createdAt = this.getAttribute('createdAt');
      const archived = this.getAttribute('archived');
  
      // Membuat elemen HTML untuk catatan
      this.innerHTML = `
      <div class="note-card">
          <h2>${title}</h2>
          <p>${body}</p>
          <p>Created at: ${new Date(createdAt).toLocaleDateString()}</p>
          <p>Archived: ${archived}</p>
          <button class="archive-btn"><i class="fas fa-archive"></i> Archive</button>
          <button class="delete-btn"><i class="fas fa-trash-alt"></i> Delete</button>
      </div>
     `;
  
 // Menambahkan event listener untuk tombol arsip
 if (archived === "true") {
  this.querySelector(".unarchive-btn").addEventListener("click", () => {
    this.unarchiveNoteWithAPI(id);
  });
} else {
  this.querySelector(".archive-btn").addEventListener("click", () => {
    this.archiveNoteWithAPI(id);
  });
}
    }
 
    
    async archiveNoteWithAPI(noteId) {
      try {
          // Your existing code for archiving a note...
      } catch (error) {
          console.error("Error archiving note:", error);
          alert("Gagal mengarsipkan catatan. Terjadi kesalahan.");
      }
  }

  async unarchiveNoteWithAPI(noteId) {
    try {
        // Your existing code for unarchiving a note...
    } catch (error) {
        console.error("Error unarchiving note:", error);
        alert("Gagal melakukan unarchive catatan. Terjadi kesalahan.");
    }
}    
async deleteNote(id) {
  try {
      const response = await fetch(`https://notes-api.dicoding.dev/v2/notes/${id}`, {
          method: 'DELETE'
      });

      if (response.ok) {
          await document.dispatchEvent(new CustomEvent('noteDeleted')); // Panggil event noteDeleted
          this.remove(); // Hapus elemen note-card dari DOM
          alert('Catatan berhasil dihapus!');
      } else {
          const errorMessage = await response.text();
          alert(`Failed to delete note: ${errorMessage}`);
      }
  } catch (error) {
      console.error('Error deleting note:', error);
      alert('Failed to delete note. Please try again later.');
  }
}


async deleteNoteInAPI(noteId) {
  try {
      // Your existing code for deleting a note...
  } catch (error) {
      console.error("Error deleting note:", error);
      alert("Gagal menghapus catatan. Terjadi kesalahan.");
  }
}

showLoader() {
  const loader = document.createElement("div");
  loader.classList.add("loader");
  document.body.appendChild(loader);
}
}

// Kelas NoteList untuk menampilkan daftar catatan
class NoteList extends HTMLElement {
    
  constructor() {
    super();
    this.notesData = [];
  }

  connectedCallback() {
  // Panggil metode fetchNotesFromAPI dan tambahkan event listener untuk noteAdded
  this.fetchNotesFromAPI();
      // Tambahkan event listener untuk noteAdded
    document.addEventListener("noteAdded", this.refresh.bind(this));
    document.addEventListener("noteArchived", this.archiveNote.bind(this));

    document.addEventListener(
      "notesUpdated",
      this.fetchAndRenderNotes.bind(this)
    );

    // Tambahkan event listener untuk tombol cari
    const searchButton = document.getElementById("searchButton");
    searchButton.addEventListener("click", this.searchNotes.bind(this));

    // Tambahkan event listener untuk tombol reset
    const resetButton = document.getElementById("resetButton");
    resetButton.addEventListener("click", this.resetSearch.bind(this));

    // Tambahkan event listener untuk noteUnarchived
    document.addEventListener("noteUnarchived", (event) => {
      const { detail: noteId } = event;
      this.unarchiveNoteInData(noteId); // Mengubah status catatan di data.js
      this.render(); // Memperbarui tampilan setelah catatan diunarchive
    });
  }

  async fetchAndRenderNotes() {
    await this.fetchNotesFromAPI(); // Mengambil data terbaru dari API
    this.render(); // Merender ulang daftar catatan
  }

  async searchNotes() {
    const searchInput = document
      .getElementById("searchInput")
      .value.trim()
      .toLowerCase();

    // Render catatan yang cocok dengan kriteria pencarian
    this.renderMatchedNotes(matchedNotes);
  }
  renderMatchedNotes(matchedNotes) {

    // Render catatan yang cocok dengan kriteria pencarian
    const matchedNoteSection = document.createElement("div");
    matchedNoteSection.classList.add("noteList-section");
    matchedNoteSection.innerHTML = "<h2>Search Results</h2>";
    matchedNotes.forEach((note) => {
      const noteCard = document.createElement("note-card");
      Object.entries(note).forEach(([key, value]) => {
        noteCard.setAttribute(key, value);
      });
      matchedNoteSection.appendChild(noteCard);
    });
    this.appendChild(matchedNoteSection);
  }

  unarchiveNoteInData(noteId) {
    // Temukan catatan berdasarkan ID
    const note = this.notesData.find((note) => note.id === noteId);
    if (note) {
      note.archived = false; // Mengubah status menjadi non-archived (normal)
    }
  }

  async fetchArchivedNotesFromAPI() {
    try {
      const response = await fetch(`${baseURL}/notes/archived`);
      const data = await response.json();
      if (response.ok) {
        return data.data;
      } else {
        console.error("Failed to fetch archived notes:", data.message);
        return [];
      }
    } catch (error) {
      console.error("Error fetching archived notes from API:", error);
      return [];
    }
  }

  async fetchNotesFromAPI() {
    try {
      const response = await fetch(apiUrl);
      if (!response.ok) {
        throw new Error('Failed to fetch notes');
      }
      const data = await response.json();
      notesData = data;
      console.log(notesData["data"]);
      return notesData;
    } catch (error) {
      console.error('Error fetching notes:', error);
      alert('Failed to fetch notes. Please try again later.');
    }
    this.render();
  }
  render() {
    // Render daftar catatan berdasarkan data yang diambil dari API
    this.innerHTML = "<p>ini berjalan</p>"; // Kosongkan konten sebelum memperbarui
    fetchNotesFromAPI();
    // Daftar catatan biasa
    const normalNotes = this.notesData.filter((note) => !note.archived);
    const normalNoteSection = document.createElement("div");
    normalNoteSection.classList.add("noteList-section");
    normalNoteSection.innerHTML = "<h2>Notes</h2>";
    normalNotes.forEach((note) => {
      const noteCard = document.createElement("note-card");
      Object.entries(note).forEach(([key, value]) => {
        noteCard.setAttribute(key, value);
      });
      normalNoteSection.appendChild(noteCard);
    });
    this.appendChild(normalNoteSection);

    // Daftar catatan arsip
    const archivedNotes = this.notesData.filter((note) => note.archived);
    if (archivedNotes.length > 0) {
      const archivedNoteSection = document.createElement("div");
      archivedNoteSection.classList.add("noteArchived-section");
      archivedNoteSection.innerHTML = "<h2>Archived Notes</h2>";
      archivedNotes.forEach((note) => {
        const noteCard = document.createElement("note-card");
        Object.entries(note).forEach(([key, value]) => {
          noteCard.setAttribute(key, value);
        });
        const unarchiveButton = document.createElement("button");
        unarchiveButton.innerHTML = '<i class="fas fa-archive"></i> Unarchive';
        unarchiveButton.addEventListener("click", () => {
          this.unarchiveNoteInAPI(note.id);
        });
        noteCard.appendChild(unarchiveButton);
        archivedNoteSection.appendChild(noteCard);
      });
      this.appendChild(archivedNoteSection);
    }
  }

  refresh() {
    this.fetchNotesFromAPI(); // Ambil kembali catatan dari API dan render ulang
  }
  
  archiveNote(event) {
    const { detail: noteId } = event;
    const noteIndex = this.notesData.findIndex((note) => note.id === noteId);
    if (noteIndex !== -1) {
      this.notesData[noteIndex].archived = true;
      this.render(); // Memperbarui tampilan setelah mengarsipkan catatan
    }
  }

  resetSearch() {
    document.getElementById("searchInput").value = ""; // Kosongkan input pencarian
    this.filteredNotes = []; // Kosongkan array filteredNotes
    this.render(); // Render ulang untuk menampilkan semua catatan tanpa filter
  }
}





// Mendaftarkan custom elements
 customElements.define('note-card', NoteCard);
 customElements.define('note-list', NoteList);

 export default {NoteCard, NoteList};