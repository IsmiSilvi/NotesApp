const apiUrl = 'https://notes-api.dicoding.dev/v2/notes';
class NoteForm extends HTMLElement {
  
    constructor() {
      super();
    }

    render(){
      
    }
  
    connectedCallback() {
      // Initialize addNote method as an arrow function to maintain the correct 'this' context
      this.addNote = this.addNote.bind(this);
  
      this.innerHTML = `
        <div class="note-form">
          <h1>Form Catatan</h1>
          <input type="text" id="titleInput" placeholder="Title">
          <div id="titleCharCount" class="char-count">0/50</div>
          <textarea id="bodyInput" placeholder="Body"></textarea>
          <div id="bodyCharCount" class="char-count">0/1000</div>
          <button id="submitBtn" disabled><i class="fas fa-plus"></i> Add Note</button>
          <div id="errorMessages"></div>
        </div>
      `;
  
      const titleInput = this.querySelector('#titleInput');
      const bodyInput = this.querySelector('#bodyInput');
      const submitBtn = this.querySelector('#submitBtn');
      const errorMessages = this.querySelector('#errorMessages');
      // const loading = this.querySelector("#loading"); // Ambil elemen loading
  
      const updateSubmitButton = () => {
        const titleValue = titleInput.value.trim();
        const bodyValue = bodyInput.value.trim();
        const errors = [];
  
        if (titleValue === '') {
          errors.push('Title is required.');
        }
        if (titleValue.length > 50) {
          errors.push('Title cannot exceed 50 characters.');
        }
        if (bodyValue === '') {
          errors.push('Body is required.');
        }
        if (bodyValue.length > 1000) {
          errors.push('Body cannot exceed 1000 characters.');
        }
  
        submitBtn.disabled = errors.length > 0;
        errorMessages.innerHTML = errors.map(error => `<div>${error}</div>`).join('');
      };
  
      titleInput.addEventListener('input', () => {
        let titleValue = titleInput.value;
        if (titleValue.length > 50) {
          titleInput.value = titleValue.slice(0, 50);
        }
        const charCount = titleInput.value.length;
        titleCharCount.textContent = `${charCount}/50`;
        updateSubmitButton();
      });
  
      bodyInput.addEventListener('input', () => {
        let bodyValue = bodyInput.value;
        if (bodyValue.length > 1000) {
          bodyInput.value = bodyValue.slice(0, 1000);
        }
        const charCount = bodyInput.value.length;
        bodyCharCount.textContent = `${charCount}/1000`;
        updateSubmitButton();
      });
  
      submitBtn.addEventListener('click', () => {
        const titleValue = titleInput.value.trim();
        const bodyValue = bodyInput.value.trim();
  
        if (titleValue === '' || bodyValue === '') {
          errorMessages.innerHTML = '<div>All fields are required.</div>';
        } else {
          this.addNote();
          errorMessages.innerHTML = 'loading.....';
        }
      });
    }
  
    async addNote() {
      const titleValue = this.querySelector('#titleInput').value.trim();
      const bodyValue = this.querySelector('#bodyInput').value.trim();
      if (titleValue === '' || bodyValue === '') {
        // Handle error case
      } else {
        try {
          const response = await fetch(`${apiUrl}`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              title: titleValue,
              body: bodyValue,
            }),
          });
          if (response.ok) {
            // Reset form
            this.querySelector('#titleInput').value = '';
            this.querySelector('#bodyInput').value = '';
            // Dispatch event to notify that a note has been added
            document.dispatchEvent(new CustomEvent('noteAdded'));

            errorMessages.innerHTML = '';
            // Display success message
            alert('Catatan berhasil ditambahkan!');
          } else {
            // Handle error case
            alert('Gagal menambahkan catatan. Silakan coba lagi.');
          }
        } catch (error) {
          // Handle error case
          console.error('Error adding note:', error);
          alert('Gagal menambahkan catatan. Terjadi kesalahan.');
        }
      }
    }
  
  
  showLoader() {
    const loader = document.createElement("div");
    loader.classList.add("loader");
    document.body.appendChild(loader);
  }
  }
  customElements.define('notes-form', NoteForm);

  export default NoteForm;
