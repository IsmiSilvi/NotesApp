class NoteCardList extends HTMLElement {
    
    constructor() {
        super();

        this._noteList = [];

        this._style = document.createElement('style');
      }

      setNoteList(value) {
        this._noteList = value;

        // Render ulang setelah `blogList` di-update
        this.render();
      }

      connectedCallback() {
        this.render();
        console.log('Custom element ditambahkan ke halaman.');
      }
    
      disconnectedCallback() {
        console.log('Custom element disingkirkan dari halaman.');
      }
    
      adoptedCallback() {
        console.log('Custom element dipindahkan ke halaman baru.');
      }
    
      attributeChangedCallback(name, oldValue, newValue) {
        console.log(`Attribute ${name} telah diubah.`);
      }

      updateStyle() {
        this._style.textContent = `
        note-list-card {
            display: grid;
    
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
          }
        `;
      }
      

    render() {
       this.updateStyle();

       const noteItemElements = this._noteList.map((item) => {
        console.log(item['id']);
        const note = document.createElement('item-list-card');
        note.setNote(item);
        
        return note;
      });
  
      this.innerHTML = '';
      this.append(this._style, ...noteItemElements);
    }

    
}
customElements.define('note-list-card', NoteCardList);

export default NoteCardList;
