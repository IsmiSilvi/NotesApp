import NotesApi from '../data/remote/notes-api.js'

class NoteCardItem extends HTMLElement {
    
    
  constructor() {
    super();

    this._note = {
        id : 'NEED_ID',
        title: 'NEED_TITLE',
        body: 'NEED_BODY',
        createdAt: 'NEED_DATE',
        archived: false
    };

    this._style = document.createElement('style');
  }

  setNote(value) {
    this._note['id'] = value.id;
    this._note['title'] = value.title;
    this._note['body'] = value.body;
    this._note['createdAt'] = value.createdAt;
    this._note['archived'] = value.archived;
    // Render ulang setelah `note` di-update
    this.render();
  }

  connectedCallback() {
    // this.render();
    this.listenButton();
    console.log('Custom element ditambahkan ke halaman.');
  }

  disconnectedCallback() {
    console.log('Custom element disingkirkan dari halaman.');
  }

  adoptedCallback() {
    console.log('Custom element dipindahkan ke halaman baru.');
  }

  attributeChangedCallback(name, oldValue, newValue) {
    console.log(`Attribute ${name} telah diubah.`);
  }

  updateStyle() {
    this._style.textContent = `
    item-list-card {
        padding: 1rem 0.8rem;
        display: block;

        border-radius: 4px;
        box-shadow: 0 0 2px 2px #33333377;
      }

      .note_title {
        margin-block-start: 0;
        margin-block-end: 1rem;

        font-size: 1.3em;
        font-weight: bold;
      }

      p {
        margin-block-start: 0;
      }
    `;
  }
  listenButton(){
    this.querySelector(".delete-button").addEventListener("click", () => {
      NotesApi.removeNote(this._note.id);
    });
    // return this.render();
  }
render() {
   this.updateStyle();

    this.setAttribute('data-id', this._note.id);
    console.log("sama 2");
    this.innerHTML = `
    ${this._style.outerHTML}
      <h2 class="note_title">${this._note.title}</h2>
      <p>${this._note.body}</p>
      <p>Created at: ${new Date(this._note.createdAt).toLocaleDateString()}</p>
      <p>Archived: ${this._note.archived}</p>
      <button class="archive-btn"><i class="fas fa-archive"></i> Archive</button>
      <button class="delete-button" data-id="${this._note.id}"><i class="fas fa-trash-alt"></i> Delete</button>
 ` 
}
    
}
customElements.define('item-list-card', NoteCardItem);

export default NoteCardItem;
