import Utils from '../script/utils.js';
import NotesApi from '../data/remote/notes-api.js';

const home = () => {
    const searchFormElement = document.querySelector('search-bar');
  
    const noteListContainerElement = document.querySelector('#noteListContainer');
    const clubQueryWaitingElement = noteListContainerElement.querySelector('.query-waiting');
    const clubLoadingElement = noteListContainerElement.querySelector('.search-loading');
    const clubSearchErrorElement = noteListContainerElement.querySelector('club-search-error');
    const clubListElement = noteListContainerElement.querySelector('club-list');
  
    const showSportClub = (query) => {
      showLoading();
  
      SportsApi.searchClub(query)
        .then((result) => {
          displayResult(result);
  
          showClubList();
        })
        .catch((error) => {
          clubSearchErrorElement.textContent = error.message;
          showSearchError();
        });
    };
  
    const onSearchHandler = (event) => {
      event.preventDefault();
  
      const { query } = event.detail;
      showSportClub(query);
    };
  
    const displayResult = (clubs) => {
      const clubItemElements = clubs.map((club) => {
        const clubItemElement = document.createElement('club-item');
        clubItemElement.club = club;
  
        return clubItemElement;
      });
  
      Utils.emptyElement(clubListElement);
      clubListElement.append(...clubItemElements);
    };
  
    const showClubList = () => {
      Array.from(noteListContainerElement.children).forEach((element) => {
        Utils.hideElement(element);
      });
      Utils.showElement(clubListElement);
    };
  
    const showLoading = () => {
      Array.from(noteListContainerElement.children).forEach((element) => {
        Utils.hideElement(element);
      });
      Utils.showElement(clubLoadingElement);
    };
  
    const showQueryWaiting = () => {
      Array.from(noteListContainerElement.children).forEach((element) => {
        Utils.hideElement(element);
      });
      Utils.showElement(clubQueryWaitingElement);
    };
  
    const showSearchError = () => {
      Array.from(noteListContainerElement.children).forEach((element) => {
        Utils.hideElement(element);
      });
      Utils.showElement(clubSearchErrorElement);
    };
  
    // searchFormElement.addEventListener('search', onSearchHandler);
    showQueryWaiting();
  };
  
  export default home;