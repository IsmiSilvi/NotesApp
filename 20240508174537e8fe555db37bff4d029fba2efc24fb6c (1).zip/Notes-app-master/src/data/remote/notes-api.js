const BASE_URL = ' https://notes-api.dicoding.dev/v2';

class NotesApi {
  static getNote() {
    return fetch(`${BASE_URL}/notes`)
      .then((response) => {
        if (response.status >= 200 && response.status < 300) {
          console.log("ok");
          return response.json();
        } else {
          return Promise.reject(new Error(`Something went wrong`));
        }
      })
      .then((responseJson) => {
        const { data : notes } = responseJson;
        
        const notedata = responseJson;
        // console.log(notedata['data']);
        if (notes.length > 0) {
          return notedata['data'];
        } else {
          return Promise.reject(new Error(`file get  is not found`));
        }
      });
  }

  static searchNote =(data,keyword)=>{
    return data.filter((note) => {
      const loweredCaseNoteName = (note.titleValue || '-').toLowerCase();
      const jammedClubName = loweredCaseNoteName.replace(/\s/g, '');

      const loweredCaseQuery = keyword.toLowerCase();
      const jammedQuery = loweredCaseQuery.replace(/\s/g, '');

      return jammedClubName.indexOf(jammedQuery) !== -1;
    });
  }

  static removeNote = (noteId) => {
    // Membuat instance dari XMLHttpRequest
    const xhr = new XMLHttpRequest();

    // Menetapkan callback jika response sukses dan error
    xhr.onload = function () {
      const responseJson = JSON.parse(this.responseText);
      alert(responseJson.message);

      NotesApi.getNote();
    };

    xhr.onerror = function () {
      alert(message);
    };

    // Membuat DELETE request dan menetapkan target URL
    xhr.open('DELETE', `${BASE_URL}/notes/${noteId}`);

    // Mementapkan properti Content-Type dan X-Auth-Token pada Header request
    xhr.setRequestHeader('X-Auth-Token', '12345');

    // Mengirimkan request
    xhr.send();
  };

  static addNote(titleValue, bodyValue) {
    return fetch(`${BASE_URL}/notes`,{
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        title: titleValue,
        body: bodyValue,
      }),
    })
      .then((response) => {
        if (response.status >= 200 && response.status < 300) {
          this.querySelector('#titleInput').value = '';
          this.querySelector('#bodyInput').value = '';
          // Dispatch event to notify that a note has been added
          document.dispatchEvent(new CustomEvent('noteAdded'));
          // Display success message
          alert('Catatan berhasil ditambahkan!');
          return response.json();
        } else {
          return Promise.reject(new Error(`Something went wrong`));
        }
      })
      .then((responseJson) => {
        return responseJson;
      });
  }
}

export default NotesApi;


// Fungsi untuk mendapatkan daftar catatan dari API
async function getNotesFromAPI() {
  try {
      const response = await fetch(apiUrl);
      if (!response.ok) {
          throw new Error('Failed to fetch notes');
      }
      const data = await response.json();
      notesData = data; // Setel notesData dengan data dari API
      // renderNoteList(); // Render ulang daftar catatan setelah mendapatkan data dari API
  } catch (error) {
      console.error('Error fetching notes:', error);
      alert('Failed to fetch notes. Please try again later.');
  }
}

