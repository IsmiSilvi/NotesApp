
import "./components/form-notes.js"
import "./components/list-notes.js"
import "./components/list-card-note.js"
import "./components/item-card-note.js"
import "./components/search-note.js"
import "./components/loading.js"
import NotesApi from '.././src/data/remote/notes-api.js'
import Utils from './script/utils.js'


const noteListEl = document.querySelector('note-list-card');
const searchNote = document.querySelector('search-note');
const searchInput = document.querySelector('searchInput');
const noteaddEl = document.querySelector('submitBtn');
const noteContainerElement = document.querySelector('#note-container');
const noteQueryWaitingElement = noteContainerElement.querySelector('.query-waiting');
const noteEmptyElement = noteContainerElement.querySelector('.note-empty');
const noteLoadingElement = noteContainerElement.querySelector('.search-loading');
const deleteButtonElements = document.querySelectorAll('delete-button');

// let searceValue ='';
//getting data from api get all
// noteListEl.setNoteList(data);

// noteaddEl.addEventListener('click', () => {
//     showListNote();
//    });



const showLoading=()=>{
    Array.from(noteContainerElement.children).forEach((element) => {
        Utils.hideElement(element);
      });
      Utils.showElement(noteLoadingElement);
};

const showNoteList=()=>{
    Array.from(noteContainerElement.children).forEach((element) => {
        Utils.hideElement(element);
      });
      Utils.showElement(noteListEl);
};

const showEmpty=()=>{
    Array.from(noteContainerElement.children).forEach((element) => {
        Utils.hideElement(element);
      });
      Utils.showElement(noteEmptyElement);
};
var data = await NotesApi.getNote();
const showListNote = ()=>{
    showLoading();
    noteListEl.setNoteList(data);
            let newData = searchNote.listenButtonToSearch(data); 
            console.log(newData)
           if(data.length != 0){
            if (newData.length == 0){
                noteListEl.setNoteList(data);
                showNoteList();
            }else{
                noteListEl.setNoteList(newData);
                showNoteList();
            }
           }
        
  
    
}

deleteButtonElements.forEach((button)=>{
    console.log("disini delete");
    button.addEventListener('click', (event)=>{
        const noteId = event.target.data.id;
        console.log("diklik delete");
        NotesApi.removeNote(noteId);
    })
});



showListNote();